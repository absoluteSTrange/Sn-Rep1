<!-- !! LISTEN UP PAVAN AND NAVEEN (ME) THIS IS WHERE THE TODO LIST IS GONNA BE -->
<!-- !! THE ISSUES ON THIS LIST BE COMPLETED/FIXED BY ANYONE-->

<!-- ? not completed stuff -->
<!-- TODO: Make the homepage responsive (fix the images - maybe naveen will do it) // not done-->
<!-- TODO: Fix the nav bar (Naveen will do it) // not done-->
<!-- TODO: Create logo (both can do (naveen and pavan) )  // not done-->
<!-- TODO: Plan about the videos page (need to discuss) // not done-->
<!-- TODO: Add a footer (naveen will do it) // not done-->

<!-- * completed stuff -->
<!-- TODO: Complete Home page-->
<!-- TODO: Complete Navigations-->
<!-- TODO: Create error 404 page-->
